package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
class MainActivity : AppCompatActivity() {
    fun onCreate(savedInstanceState: Bundle?, eTinput1: Any) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)


    }
}


